package org.lwjgl.test.opengles.util;

public interface GLObject {

	int getID();

	void destroy();

}